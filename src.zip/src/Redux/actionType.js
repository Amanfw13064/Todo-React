

export const Add_Loading="Add_Loading"

export const Add_Success="Add_Success"

export const Get_Loading="Get_Loading"

export const Get_Success="Get_Success"